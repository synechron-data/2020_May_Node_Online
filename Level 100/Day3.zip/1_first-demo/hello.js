// var name = "Synechron";
// console.log("Hello,", name);

// console.log(__dirname);
// console.log(process);
// console.log(process.cwd());
// console.log(__filename);

// var a = 10;
// console.log(a);
// console.log(typeof a);

// function add(x = 0, y = 0) {
//     return x + y;
// }

// console.log(add(2, 3));
// console.log(add(2));
// console.log(add());

class Employee {
    constructor(name) {
        this._name = name;
    }

    get Name() {
        return this._name;
    }

    set Name(value) {
        this._name = value;
    }
}

var e1 = new Employee("Manish");
console.log(e1.Name);
e1.Name = "Abhijeet";
console.log(e1.Name);
