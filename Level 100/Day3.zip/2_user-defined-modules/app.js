// require('./lib.js');

// const lib = require('./lib.js');
// console.log(lib);

// console.log(lib.firstname);
// console.log(lib.lastname);
// lib.log("Hi From Main Module");

// var e1 = new lib.Employee("Manish");
// console.log(e1.Name);
// e1.Name = "Abhijeet";
// console.log(e1.Name);

// const { Employee } = require('./lib.js');

// var e1 = new Employee("Manish");
// console.log(e1.Name);
// e1.Name = "Abhijeet";
// console.log(e1.Name);

// const { Employee } = require('./lib');

// var e1 = new Employee("Manish");
// console.log(e1.Name);
// e1.Name = "Abhijeet";
// console.log(e1.Name);

// Module is required and loaded only once and from next require the cached copy is used 
// const logger1 = require('./logger');
// const logger2 = require('./logger');
// console.log(logger1 === logger2);

// const logger = require('./logger');

// const logger = require('./logger/test.js');
// const logger = require('./logger/test');

// -----------------------------------------------------------------------------------
// const Logger = require('./loggerService/Logger');
// let logger = new Logger();
// logger.log("Hello from App Module");

// const loggerService = require('./loggerService');
// loggerService.log("Hello from App Module");

// -----------------------------------------------------------------------------------
// const loggerSingle = require('./loggerSingle');

// var l1 = loggerSingle.getLogger();
// l1.log("Hi from App Module");

// var l2 = loggerSingle.getLogger();
// l2.log("Hi from App Module");

// console.log(l1 === l2);

// -----------------------------------------------------------------------------------

// const loggerFactory = require('./loggerFactory');

// // console.log(loggerFactory);

// let dbLogger = loggerFactory.DBLFactory.getLogger();
// let flLogger = loggerFactory.FLFactory.getLogger();

// dbLogger.log("Hello from App Module");
// flLogger.log("Hello from App Module");

const { DBLFactory, FLFactory } = require('./loggerFactory');

let dbLogger = DBLFactory.getLogger();
let flLogger = FLFactory.getLogger();

dbLogger.log("Hello from App Module");
flLogger.log("Hello from App Module");