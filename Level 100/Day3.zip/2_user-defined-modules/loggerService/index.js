const Logger = require('./Logger');

exports.log = function (message) {
    let logger = new Logger();
    logger.log(message);
}