const Logger = require('./Logger');
let instance = null;

exports.getLogger = function () {
    if (!instance)
        instance = new Logger();
    return instance;
}