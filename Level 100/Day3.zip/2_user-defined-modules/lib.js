// console.log(module);

// var fname = "Manish";
// module.exports = fname;

// var lname = "Sharma";
// module.exports = lname;

// var fname = "Manish";
// var lname = "Sharma";
// module.exports = {firstname: fname, lastname: lname};

// var fname = "Manish";
// var lname = "Sharma";
// module.exports.firstname = fname;
// module.exports.lastname = lname;

var fname = "Manish";
var lname = "Sharma";
exports.firstname = fname;
exports.lastname = lname;

exports.log = function (m) {
    console.log(m);
}

class Employee {
    constructor(name) {
        this._name = name;
    }

    get Name() {
        return this._name;
    }

    set Name(value) {
        this._name = value;
    }
}

exports.Employee = Employee;