'use strict'

// const a;        // Error - Missing initializer in const declaration
// a = 10;
// console.log(a);

// const a = 10;
// console.log("Outside, a is: ", a);

// // a = 100;        // Error - Assignment to constant variable.
// // console.log(a);

// // if (true) {
// //     a = 100;        // Error - Assignment to constant variable.
// //     console.log(a);
// // }

// if (true) {
//     const a = 100;  
//     console.log("Inside, a is: ",a);
// }

// const person = { id: 1, name: "Manish" };

// console.log(person);
// person.id = 100;
// // person = {};        // Error - Assignment to constant variable.

// console.log(person);

let person = { id: 1, name: "Manish" };
console.log("Outside Fn: ",person);

person.id = 100;

(function () {
    // let person = { name: "ABC", city: "Pune" };
    person.name = "Abhijeet";
    console.log("Before, Inside Fn: ", person);

    if (true) {
        // let person = { name: "ABC", state: "MH" };
        person.name = "Rajesh";
        console.log("Inside Block: ", person);
    }

    console.log("After, Inside Fn: ", person);
})();

console.log("Outside Fn: ",person);

