'use strict'

// a = 10;
// console.log(a);

// function Test(){
//     a = 10;
//     console.log("Inside Function, a is: ", a);
// }

// Test();
// console.log("Outside Function, a is: ", a);

// Hositing - Hoisting is JavaScript Runtime's default behavior of moving declarations to the top.
// a = 10;
// console.log(a);
// var a;

// Definitions or Initializations are not hoisted
// console.log(a);
// var a = 10;

// After parsing code will look like below
// var a;
// console.log(a);
// a = 10;

// var a = 10;
// a = "Hello";
// console.log(a);

// var a = 10;
// var a = "Hello";
// console.log(a);

// var i = "Synechron";
// console.log("Before, i is ", i);

// for (var i = 0; i < 5; i++) {
//     console.log("Inside, i is ", i);
// }

// console.log("After, i is ", i);

// function Test() {
//     if (true) {
//         var i = 100;
//     }

//     return i;
// }

// console.log(Test());
// console.log("Outside Test, i is: ", i);

// // --------------------------------------- Solution 1
// var i = "Synechron";
// console.log("Before, i is ", i);

// for (var _i = 0; _i < 5; _i++) {
//     console.log("Inside, i is ", _i);
// }

// console.log("After, i is ", i);

// --------------------------------------- Solution 2
var i = "Synechron";
console.log("Before, i is ", i);

(function(){
    for (var i = 0; i < 5; i++) {
        console.log("Inside, i is ", i);
    }
}());

console.log("After, i is ", i);