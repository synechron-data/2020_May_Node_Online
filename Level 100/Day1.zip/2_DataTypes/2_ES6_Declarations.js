'use strict'

// let a;
// a = 10;
// console.log(a);

// let keyword is not hoisted
// a = 10;
// console.log(a);
// let a;

// let keyword will not allow your to create variables with same name in the same scope
// let a = 10;
// let a = "Hello";
// console.log(a);

// ES 3 and ES 5 Scopes
// Global Scope
// Function Scope (Local Scope)

// ECMAScript 2015 and above Scopes
// Global Scope
// Function Scope (Local Scope)
// Block Scope (let or const keyword)

// function Test() {
//     if (true) {
//         let i = 100;
//     }

//     return i;
// }

// console.log(Test());
// console.log("Outside Test, i is: ", i);

var i = "Synechron";        // Global Variable
console.log("Before, i is ", i);

// let will create a block scoped variable
for (let i = 0; i < 5; i++) {
    console.log("Inside, i is ", i);
}

console.log("After, i is ", i);