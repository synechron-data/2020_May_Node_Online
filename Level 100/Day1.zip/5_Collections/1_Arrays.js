// var employees = new Array();
// var employees = new Array(2);
// var employees = new Array(1, 2, 3, 4, 5);
// var employees = new Array('abc');
// var employees = new Array(10);
// var employees = Array.of(10);
// var employees = Array.from([10, 20, 30]);

// var employees = [10, 20, 30];

// console.log(employees);
// console.log(employees.length);
// console.log(typeof employees);

// var employees = new Array(2);
// console.log(`Length of Employees ${employees.length}`);

// // employees[0] = "Manish";
// // employees[1] = "Abhijeet";
// // employees[2] = "Pravin";
// // employees[5] = "Ramakant";

// employees.unshift("Manish");
// employees.unshift("Abhijeet");
// employees.push("Sumeet");

// console.log(`Employees ${employees}`);
// console.log(`Length of Employees ${employees.length}`);

var employees = [
    { id: 1, name: "Manish" },
    { id: 2, name: "Varun" },
    { id: 3, name: "Paresh" },
    { id: 4, name: "Devesh" },
    { id: 5, name: "Atul" },
];

// for (let i = 0; i < employees.length; i++) {
//     console.log(`${i}   ${JSON.stringify(employees[i])}`);
// }

// for (const key in employees) {
//     console.log(`${key}   ${JSON.stringify(employees[key])}`);
// }

// employees.forEach((item, index, arr) => {
//     console.log(`${index}   ${JSON.stringify(item)}`);
// });

// ES6 - ForOf Loop
// for (const item of employees) {
//     console.log(`${JSON.stringify(item)}`);
// }

for (const [index, item] of employees.entries()) {
    console.log(`${index}       ${JSON.stringify(item)}`);
}
