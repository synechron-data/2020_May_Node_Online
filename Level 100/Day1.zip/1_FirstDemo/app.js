var message = "Hello from Node";
console.log(message);       // Node Globals