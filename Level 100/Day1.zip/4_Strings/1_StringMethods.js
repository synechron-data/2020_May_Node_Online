// startsWith
// endsWith
// includes
// repeat

let str = "Hello from JS World!";

// console.log(str.startsWith("Hello"));
// console.log(str.startsWith("Hello", 5));
// console.log(str.startsWith("World!"));

// console.log(str.endsWith("World!"));
// console.log(str.endsWith("world!"));
// console.log(str.endsWith("!"));

// console.log(str.includes("JS"));
// console.log(str.includes("js"));

// console.log(str.repeat(2));
var newStr = str.repeat(3);
console.log(newStr);
console.log(str);

