const name = 'Rex';
const age = '4';

// const sentence = "My pet's name is " + name + " and he is " + age + " months old";

// Template Literals
// const sentence = `My pet's name is ${name} and he is ${age} months old`;
// console.log(sentence);

function generate(strings, ...values) {
    // console.log(strings);
    // console.log(values);
    // return "Hello";

    let str = '';

    strings.forEach((string, i) => {
        str += `${string} <span class="hl">${values[i] || ''}</span>`
    });

    return `<h2>${str}</h2>`
}

// const sentence = generate`My pet's name is ${name} and he is ${age} months old`;
// console.log(sentence);

// const root = document.querySelector('#root');
// root.innerHTML = sentence;

function sanitize(strings, ...values) {
    console.log(strings);
    console.log(values);
    return "Sanitized HTML";
    // Logic to read the strings and values for sanitization
}

const header = "Sanitizing HTML using Tagged Template Literals";
const image = sanitize`This is an image <img src="http://unsplash.it/100/100?random" onload="alert('You got attacked by XSS')"/>`;
const html = `<h2>${header}</h2>
                ${image}`;

const root = document.querySelector('#root');
root.innerHTML = html;