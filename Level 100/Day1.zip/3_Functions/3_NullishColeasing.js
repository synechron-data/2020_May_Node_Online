// let a = 0;
// let b = 10;

// const r1 = a || b;
// const r2 = a ?? b;      // ECMAScript 2020 (node 12 doesn't support)

// console.log(r1);
// console.log(r2);

"use strict";

// If value of a is not given it should be equal to b
// It means value of a should be 10, only if a is undefined or null
var a = 0;
var b = 10;
var r1 = a || b;
var r2 = a !== null && a !== void 0 ? a : b;
console.log(r1);
console.log(r2);

// console.log(Boolean(0));

// -------------------------------------------------------

// var a = 10;
// console.log(a);
// console.log(typeof a);

// a = "Hello";
// console.log(a);
// console.log(typeof a);

// a = true;
// console.log(a);
// console.log(typeof a);

// console.log(10 + 20);
// console.log(10 + "ABC");
// console.log(10 + true);

// console.log(true && true);
// console.log(true && false);

// console.log(true && "ABC");

// T && T = T
// T && F = F

// T || T = T
// T || F = T

// a || b;

// console.log(true && "ABC" || "XYZ");
// console.log(false && "ABC" || "XYZ");
