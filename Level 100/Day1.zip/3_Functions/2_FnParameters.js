// Parameter - person_name
// Argument - "Synechron"

// function hello(person_name) {
//     console.log(`Hello, ${person_name}`);
// };

// hello("Synechron");
// hello("Synechron", "Pune");
// hello();     

// -------------------------------------- Handling Less Arguments

// function add(x, y) {
//     x = x || 0;
//     y = y || 0;

//     if ((typeof x == "number") && (typeof y == "number"))
//         return x + y;

//     throw Error("Invalid Parameters");
// }

// ECMASCRIPT 2015 (Default Parameters)
// function add(x = 0, y = 0) {
//     if ((typeof x == "number") && (typeof y == "number"))
//         return x + y;

//     throw Error("Invalid Parameters");
// }

// console.log(add(2, 3));
// console.log(add(2));
// console.log(add());

// try {
//     console.log(add(2, "ABC"));
// } catch (e) {
//     console.log(e.message);
// }

// -------------------------------------- Handling Extra Arguments

// function hello(person_name) {
//     console.log(`Hello, ${person_name}`);
//     console.log(arguments);
// };

// ECMASCRIPT 2015 (Rest Parameter) - Combine comma seperated items to array
// function hello(person_name, ...args) {
//     console.log(`Hello, ${person_name}`);
//     console.log(args);
// };

// hello("Synechron");
// hello("Synechron", "Pune");
// hello("Synechron", "Pune", "Hinjewadi");
// hello("Synechron", "Pune", "Hinjewadi", "Maharashtra");

// Variable Arguments

function average(...numbers) {
    // console.log(numbers);

    var sum = 0;

    for (let i = 0; i < numbers.length; i++) {
        sum += numbers[i];
    }

    if (numbers.length)
        return sum / numbers.length;
    else
        return sum;
}

console.log(average());
console.log(average(1));
console.log(average(1, 2));
console.log(average(1, 2, 3, 4, 5));
console.log(average(1, 2, 3, 4, 5, 6, 7, 8, 9));

var arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
console.log(average(...arr));   // Spread Operator - Splits an array to comma seperated items (Array Spread)