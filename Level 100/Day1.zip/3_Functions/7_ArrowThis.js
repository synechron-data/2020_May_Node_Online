// function Test() {
//     console.log(this);
// }

// // Test();

// var p1 = { id: 1 };
// Test.call(p1);
// Test.apply(p1);


// const Test = () => {
//     console.log(this);
// }

// Test();

// var p1 = { id: 1 };
// Test.call(p1);
// Test.apply(p1);

// ‘this’ refers to the parent of the function and the object through which the function was called
// function Person() {
//     this.age = 20;

//     this.growOld = function () {
//         console.log(this);
//         this.age += 1;
//     }
// }

// var p1 = new Person();
// // console.log(p1.age);
// // p1.growOld();
// // p1.growOld();
// // p1.growOld();
// // p1.growOld();
// // console.log(p1.age);

// setInterval(p1.growOld, 2000);

// setInterval(function () {
//     console.log(p1.age);
// }, 2000);

// ------------------------------------------------------- Lexical CLosure

// function Person() {
//     var self = this;
//     self.age = 20;

//     self.growOld = function () {
//         self.age += 1;
//     }
// }

// var p1 = new Person();

// setInterval(p1.growOld, 2000);

// setInterval(function () {
//     console.log(p1.age);
// }, 2000);

// ------------------------------------------------------------- Arrow
function Person() {
    this.age = 20;

    this.growOld = () => {
        this.age += 1;
    }
}

var p1 = new Person();

setInterval(p1.growOld, 2000);

setInterval(function () {
    console.log(p1.age);
}, 2000);

// arrow functions use lexical scoping — ‘this’ refers to it’s current surrounding scope and no further.