const tArr = new Int8Array(8);
console.log(tArr);
// console.log(typeof tArr);

tArr[0] = 32;

console.log(tArr);
