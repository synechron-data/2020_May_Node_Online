// var wMap = new WeakMap();

// var o1 = { id: 1 };
// var o2 = { id: 2 };

// wMap.set(o1, "This is the value for first object key");
// wMap.set(o2, "This is the value for second object key");

// // WeakMap's are not iterable
// // for (const item of wMap) {
// //     console.log(item);
// // }

// console.log(wMap.get(o1));
// console.log(wMap.get(o2));

var map = new Map();
var wMap = new WeakMap();

(function () {
    var o1 = { id: 1 };
    var o2 = { id: 2 };

    map.set(o1, "This is the value for first object");
    wMap.set(o2, "This is the value for second object");
})();