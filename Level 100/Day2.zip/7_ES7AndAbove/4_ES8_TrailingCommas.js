// In ES6, following is already allowed
var arr = [10, 20, 30, 40,];
console.log(arr);

let person = { id: 1, name: "Manish", };
console.log(person);

// From ES8 - Trailing Commas in Fn Parameter

var fn = function (a, b, ) {
    console.log(a, b);
}

// console.log(fn);
fn(23, 45);
fn(23, 45, 54);