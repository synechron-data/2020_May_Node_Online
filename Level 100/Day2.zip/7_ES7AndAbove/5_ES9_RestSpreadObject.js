// var person = { id: 1, name: "Manish", address: { city: "Pune" } };

// // var p1 = person;

// // ES 2015 - Shallow Copy
// // var p1 = Object.assign({}, person);

// // ES 2018 - Object Spread - Shallow Copy
// var p1 = {...person};

// p1.name = "Abhijeet";
// p1.address.city = "Mumbai";

// console.log(person);
// console.log(p1);

// -------------------------------------------------------------------- Object Rest
var person = { id: 1, name: "Manish", city: "Pune", state: "MH" };

// // ES 2015 - Object Destructuring
// var { id, name } = person;

// ES 2018 - Object Destructuring with Rest
var { id, name, ...address } = person;

console.log("Id: ", id);
console.log("Name: ", name);
console.log("Address: ", address);