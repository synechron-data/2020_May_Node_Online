// let result = Math.pow(2, 4);
// console.log(result);

// // Exponentiation Operator
// let result1 = 2 ** 4;
// console.log(result1);

// -------------------------------------------------- Array Includes

let arr = ["ReactJS", "Angular", "ExtJS"];

// console.log(arr.indexOf('ReactJS'));
// console.log(Boolean(arr.indexOf('ReactJS')));

// if (arr.indexOf('ReactJS')) {
//     console.log("React is available");
// } else {
//     console.log("React is not available");
// }

// if (arr.indexOf('ExtJS')) {
//     console.log("ExtJS is available");
// } else {
//     console.log("ExtJS is not available");
// }

// if (arr.indexOf('ReactJS') !== -1) {
//     console.log("React is available");
// } else {
//     console.log("React is not available");
// }

// ES 6
// arr.find(callback Function)
// arr.findIndex(callback Function)

// ES 7
if (arr.includes('ReactJS')) {
    console.log("React is available");
} else {
    console.log("React is not available");
}