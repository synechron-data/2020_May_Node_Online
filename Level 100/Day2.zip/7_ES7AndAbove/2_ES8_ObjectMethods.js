// var person = { id: 1, name: "Manish", city: "Pune", state: "MH" };

// // ES 2015
// // for (const key of Object.keys(person)) {
// //     console.log(key);
// // }

// // ES 2017 - Object.values(), Object.Entries()

// // for (const value of Object.values(person)) {
// //     console.log(value);
// // }

// for (const [key, value] of Object.entries(person)) {
//     console.log(`${key}        ${value}`);
// }

// ------------------------------------------------- getOwnPropertyDescriptor()

var person = {};

Object.defineProperty(person, "firstname", {
    value: "NA",
    writable: true,
    enumerable: true
});

// console.log(person.firstname);
// person.firstname = "Manish";
// console.log(person.firstname);

var desp = Object.getOwnPropertyDescriptor(person,'firstname');
console.log(desp);