const localApi = {
    getAllPostsUsingCB(successCB, errorCB) {
        fetch('https://jsonplaceholder.typicode.com/posts').then((response) => {
            var result = response.json();
            result.then(data => {
                successCB(data);
            }).catch(err => {
                errorCB("JSON Parse Error");
            })
        }).catch((err) => {
            errorCB("Communication Error");
        })
    },

    getAllPostsUsingPromise() {
        var promise = new Promise((resolve, reject) => {
            fetch('https://jsonplaceholder.typicode.com/posts').then((response) => {
                var result = response.json();
                result.then(data => {
                    resolve(data);
                }).catch(err => {
                    reject("JSON Parse Error");
                })
            }).catch((err) => {
                reject("Communication Error");
            })
        });

        return promise;
    }
};