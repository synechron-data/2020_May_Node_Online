var promise = new Promise((resolve, reject) => {
    setTimeout(function () {
        // resolve("Hello, it is a success");
        reject("Ohh, there is a rejection");
    }, 5000);
});

// promise.then((msg) => {
//     console.log("Success - ", msg);
// }, (emsg) => { 
//     console.log("Error - ", emsg);
// });

// promise.then((msg) => {
//     console.log("Success - ", msg);
// }).catch((emsg) => { 
//     console.log("Error - ", emsg);
// });

// Promise: finally() came in ES9 (ECMASCRIPT 2018)
promise.then((msg) => {
    console.log("Success - ", msg);
}).catch((emsg) => {
    console.log("Error - ", emsg);
}).finally(() => {
    console.log("I am the finally block");
});