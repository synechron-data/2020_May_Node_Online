const calculator = (function () {
    var add = function (x, y) {
        return x + y;
    }

    var subtract = function (x, y) {
        return x - y;
    }

    var multiply = function (x, y) {
        return x * y;
    }

    var divide = function (x, y) {
        return x / y;
    }

    return { add, multiply, subtract, divide };
})();

// console.log(calculator);

// ES5 way of destructuring
// const add = calculator.add;
// const subtract = calculator.subtract;

// ES6 way of object destructuring
// const { add, subtract } = calculator;

// console.log(add(2, 3));
// console.log(subtract(2, 3));

var person = { id: 1, name: "Manish", address: { city: "Pune", state: "MH" } };

// var address = person.address;

var { address } = person;

console.log(address);