class Vehicle {
    constructor(m) {
        this._make = m || "Honda";
    }

    start() {
        return `${this._make}, engine started`;
    }
}

class FourWheeler extends Vehicle {
    constructor(mk, md) {
        // Must call super constructor in derived class before accessing 'this' or returning from derived constructor
        super(mk);
        this._model = md || "Civic";
    }

    start() {
        var r = super.start(this);
        return `${r}, model is ${this._model}`;
    }

    move() {
        return "Moving like a car..";
    }
}

var v = new FourWheeler("Ford", "Mustang");
console.log(v.start());
console.log(v.move());