const calculator = (function () {
    var add = function (x, y) {
        return x + y;
    }

    var subtract = function (x, y) {
        return x - y;
    }

    var multiply = function (x, y) {
        return x * y;
    }

    var divide = function (x, y) {
        return x / y;
    }

    // return {
    //     add: add,
    //     subtract: subtract,
    //     multiply: multiply
    // };

    // ES6 - Shortcut to create Object Literals
    // return { add, multiply, subtract };

    return {
        addition: add,
        subtraction: subtract,
        multiplication: multiply
    };
})();

console.log(calculator);
// console.log(calculator.add(2, 3));