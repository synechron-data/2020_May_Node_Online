// Case 1 - Default Exports
// export default function square(x) {
//     return x * x;
// }

// Case 2 - Multiple Exports - Named Exports
// export function square(x) {
//     return x * x;
// }

// export function check(x) {
//     return "Checked " + x;
// }

// Case 3 - Default and Named Exports
// export default function square(x) {
//     return x * x;
// }

// export function check(x) {
//     return "Checked " + x;
// }

// export default class Person {
export class Person {
    constructor(name = "NA") {
        this._name = name;
    }

    getName() {
        return this._name;
    }

    setName(name) {
        this._name = name;
    }
}