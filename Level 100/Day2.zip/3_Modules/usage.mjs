// Case 1 - Default Imports
// import square from './lib.mjs';
// console.log("Result: ", square(20));

// import sqr from './lib.mjs';
// console.log("Result: ", sqr(20));

// Case 2 - Multiple Imports - Named Imports
// import { check, square } from './lib.mjs';
// console.log("Square: ", square(20));
// console.log("Check: ", check(20));

// import * as lib from './lib.mjs';
// console.log("Square: ", lib.square(20));
// console.log("Check: ", lib.check(20));

// Case 3 - Default and Named Imports
// import square, { check } from './lib.mjs';
// console.log("Square: ", square(20));
// console.log("Check: ", check(20));

// import sqr, { check } from './lib.mjs';
// console.log("Square: ", sqr(20));
// console.log("Check: ", check(20));

// node --experimental-modules usage.mjs

// import Person from './lib.mjs';
import { Person } from './lib.mjs';

var p1 = new Person("Manish");
console.log(p1.getName());
p1.setName("Abhijeet");
console.log(p1.getName());

var p2 = new Person("Pravin");
console.log(p2.getName());
p2.setName("Ramakant");
console.log(p2.getName());