function add(x, y) {
    return x + y;
    // throw Error("Got Exception");
}

let handler = {
    // Trap - Whenever a Function is invoked
    apply: function (target, thisArg, argsList) {
        try {
            // return target(...argsList);
            // return target.call(thisArg, ...argsList);
            return target.apply(thisArg, argsList);
        } catch (e) {
            console.log(e.message);
        }
    }
};

var addProxy = new Proxy(add, handler);
console.log("Result: ", addProxy(2, 3));

// try {
//     console.log("Result: ", add(2, 3));
// } catch (e) {
//     console.log(e.message);
// }