// The Proxy object is used to define custom behavior for fundamental operations

// ‘in place of’, ‘representing’ or ‘on behalf of’ are literal meanings of proxy 
// Proxies are also called surrogates, handlers, and wrappers.
// Control and manage access to the object you want to protect

// let errObject = {
//     code: "0x1001",
//     message: "Check you code for error"
// };

// console.log(errObject.code);
// console.log(errObject.message);
// console.log(errObject.source);

// -----------------------------------------------------------------

// var p = new Proxy(target, handler);

// target = Object which the proxy is wrapping
// handler = Object which the trap for any fundamental operation
// trap = Methods that provide fundamental operations

// Target
let errObject = {
    code: "0x1001",
    message: "Check you code for error"
};

// Handler
let handler = {
    // Trap
    get: function(target, key){
        return key in target ? target[key] : `${key} - Property not found...`;
    }
};

let errProxy = new Proxy(errObject, handler);

console.log(errProxy.code);
console.log(errProxy.message);
console.log(errProxy.source);