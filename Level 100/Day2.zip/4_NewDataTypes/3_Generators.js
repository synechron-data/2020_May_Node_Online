function* idGenerator() {
    // yield 1;
    // yield 2;
    // yield 3;

    let index = 0;
    while (true) {
        yield index++;
    }
}

let seq = idGenerator();

// console.log(seq.next());

for (let i = 0; i < 3; i++) {
    console.log(seq.next());
}