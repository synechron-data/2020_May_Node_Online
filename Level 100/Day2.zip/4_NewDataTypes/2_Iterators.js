// Builtin Symbols are also called Well Know Symbols
// Symbol.iterator
// Symbol.search
// Symbol.toStringTag
// Symbol.toPrimitive
// Symbol.hasInstance
// Symbol.prototype

class Queue {
    constructor() {
        this._dataArray = [];
    }

    push(data) {
        this._dataArray.push(data);
    }

    pop() {
        return this._dataArray.shift();
    }

    *[Symbol.iterator]() {
        yield* this._dataArray;
    }

    // *[Symbol.iterator]() {
    //     for (let i = 0; i < this._dataArray.length; i++) {
    //         yield this._dataArray[i];
    //     }
    // }

    // [Symbol.iterator]() {
    //     let i = 0;
    //     return {
    //         next: () => {
    //             let v, d = true;

    //             if (this._dataArray[i] !== undefined) {
    //                 v = this._dataArray[i];
    //                 d = false;
    //                 i += 1;
    //             }

    //             return {
    //                 value: v,
    //                 done: d
    //             };
    //         }
    //     };
    // }

    // [Symbol.iterator]() {
    //     let i = 0;
    //     const self = this;
    //     return {
    //         next: function () {
    //             let v, d = true;

    //             if (self._dataArray[i] !== undefined) {
    //                 v = self._dataArray[i];
    //                 d = false;
    //                 i += 1;
    //             }

    //             return {
    //                 value: v,
    //                 done: d
    //             };
    //         }
    //     };
    // }
}

var numberQ = new Queue();

numberQ.push(10);
numberQ.push(20);
numberQ.push(30);
numberQ.push(40);

// console.log(numberQ.pop());
// console.log(numberQ.pop());
// console.log(numberQ.pop());
// console.log(numberQ.pop());
// console.log(numberQ.pop());

for (const item of numberQ) {
    console.log(item);
}