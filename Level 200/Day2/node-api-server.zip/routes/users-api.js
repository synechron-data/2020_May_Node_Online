var express = require('express');
var router = express.Router();

const userApiCtrl = require('../controllers/user-api-controller');

// Enabling CORS
router.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    // res.header("Access-Control-Allow-Origin", "http://localhost:8000");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

const jwt = require('jsonwebtoken');

router.use(function (req, res, next) {
    var token = req.headers["x-access-token"];

    if (token) {
        jwt.verify(token, "test", function (err, decoded) {
            if (err) {
                res.send(403).json({
                    success: false,
                    message: "Invalid Token Found"
                });
            } else {
                next();
            }
        })
    } else {
        res.send(403).json({
            success: false,
            message: "No Token Found"
        });
    }
});

router.get('/', userApiCtrl.getUsers);

// router.post('/', userApiCtrl.postUser);

// router.put('/', userApiCtrl.putUser);

router.delete('/:userid', userApiCtrl.deleteUser);

module.exports = router;
