var express = require('express');
var router = express.Router();

const userCtrl = require('../controllers/user-controller');
const accCtrl = require('../controllers/account-controller');

router.use(accCtrl.isAuthenticated);

router.get('/', userCtrl.index);

module.exports = router;
