const da = require('../data-access');

exports.getUsers = function (req, res, next) {
    da.getAllUsers().then((result) => {
        res.json({ data: result, message: "Success, Getting Users" });
    }, (eMsg) => {
        res.json({ data: [], message: "Error, Getting Users" });
    });
};

exports.deleteUser = function (req, res, next) {
    var id = req.params.userid;
    // console.log(id);

    da.deleteUser(id).then((result) => {
        res.json({ message: "Success, Deleting Users" });
    }, (eMsg) => {
        res.send({ message: "User not found." });
    });
};