const fs = require('fs-extra');

// fs.copy('./tmp/myfile.txt', './tmp/mynewfile.txt', function (err) {
//     if (err)
//         console.error(err);

//     console.log('File copied');
// });

// fs.copy('./tmp/mydir', './tmp/mynewdir', function (err) {
//     if (err)
//         console.error(err);

//     console.log('Directory copied');
// });

// -----------------------------
// const file = './tmp/this/path/does/not/exist/file.txt';

// fs.createFile(file, function (err) {
//     if (err)
//         console.error(err);

//     console.log('File Created....');
// });

// -----------------------------
const dir = './tmp/some/long/path/does/not/exist';

fs.mkdirs(dir, function (err) {
    if (err)
        console.error(err);

    console.log('Directory Created....');
});
