var appRoot = require('app-root-path');
var winston = require('winston');

// Define the Custom Settings (File, console)
var options = {
    file: {
        level: 'info',
        filename: `${appRoot}/logs/app.log`,
        handleExceptions: true,
        json: true,
        maxsize: 524880, // 5MB
        maxFiles: 5,
        colorize: false
    },
    console: {
        level: 'info',
        handleExceptions: true,
        json: true,
        colorize: false
    }
};

var logger = winston.createLogger({
    transports: [
        new winston.transports.File(options.file),
        new winston.transports.Console(options.console)
    ],
    exitOnError: false
});

logger.stream = {
    write: function (message, encoding) {
        logger.info(message);
    }
}

module.exports = logger;