const myService = {
    MyService: {
        MyPort: {
            MyFunction: function (args) {
                return {
                    name: args.name
                };
            }
        }
    }
}

module.exports = myService;