// const url = 'http://www.dneonline.com/calculator.asmx?WSDL';
// const soap = require('soap');

// var args = { intA: 12, intB: 23 };

// soap.createClient(url, function (err, client) {
//     // console.log(client.describe());
//     client.Add(args, function (err, result) {
//         console.log(result);
//     })
// });

// const url = 'http://www.dneonline.com/calculator.asmx?WSDL';
// const soap = require('soap');

// var args = { intA: 12, intB: 23 };

// soap.createClientAsync(url).then((client) => {
//     return client.AddAsync(args);
// }).then((result) => {
//     console.log("Result is: ", result);
// });

const url = 'http://localhost:8003/wsdl?WSDL';
const soap = require('soap');

soap.createClient(url, function (err, client) {
    console.log(client.describe());
});