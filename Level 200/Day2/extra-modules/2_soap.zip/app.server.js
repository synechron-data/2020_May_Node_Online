const express = require('express');
const bodyParser = require('body-parser');
const soap = require('soap');
const myService = require('./my-service');

// console.log(myService);

var xml = require('fs').readFileSync('myservice.wsdl', 'utf-8');

var app = express();
app.use(bodyParser.raw({ type: function () { return true; }, limit: '5mb' }));
app.listen(8003, function () {
    soap.listen(app, '/wsdl', myService, xml, function () {
        console.log('server initialized..');
    });
});