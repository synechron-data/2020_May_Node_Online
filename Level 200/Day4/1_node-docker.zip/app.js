const express = require('express');

const PORT = 4000;
const HOST = '0.0.0.0';

const app = express();

app.get('/', (req, res) => {
    res.send("<h1>Hello from Docker Container<h1>");
});

app.listen(PORT, HOST);
console.log("Server started on http://" + HOST + ":" + PORT);

// docker build -t sample-nodejs-app .
// docker run -p 8080:4000 <image-id>
// docker container ls
// docker stop <container-id>

// install aws-cli
// aws configure
// Create a new Repository on AWS
// aws ecr get-login-password | docker login --username AWS --password-stdin <repository-url>
// docker tag sample-nodejs-app:latest <repository-url>
// docker push <repository-url>

// Create a new task on ECS
// Create a Cluster (EC2 Linux)
// Create a service