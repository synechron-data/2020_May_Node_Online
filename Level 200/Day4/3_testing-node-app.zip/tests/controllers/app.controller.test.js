var chai = require('chai');
var expect = chai.expect;
const sinon = require('sinon');

chai.use(require("chai-as-promised"));

const appCtrl = require('../../controllers/app.controller.js');

describe("All Tests", function () {
    describe("App Controller Tests", function () {
        it("should send Hello", function () {
            let req = {};
            let res = {
                send: sinon.spy()
            };

            appCtrl.getIndexPage(req, res);
            // console.log(res.send);
            expect(res.send.calledOnce).to.be.true;
            expect(res.send.firstCall.args[0]).to.equal("Hello");
            // expect(res.send.firstCall.args[0]).to.equal("Check");
        });

        it("should send Hello if Logged In", function () {
            let user = {
                isLoggedIn: function () { }
            }

            const isLoggedInStub = sinon.stub(user, "isLoggedIn").returns(true);

            let req = {
                user: user
            };
            let res = {
                send: sinon.spy()
            };

            appCtrl.getStubPage(req, res);
            // console.log(res.send);
            expect(res.send.calledOnce).to.be.true;
            expect(res.send.firstCall.args[0]).to.equal("Hello");
            expect(isLoggedInStub.calledOnce).to.be.true;
        });

        it("should send Error if not Logged In", function () {
            let user = {
                isLoggedIn: function () { }
            }

            const isLoggedInStub = sinon.stub(user, "isLoggedIn").returns(false);

            let req = {
                user: user
            };
            let res = {
                send: sinon.spy()
            };

            appCtrl.getStubPage(req, res);
            // console.log(res.send);
            expect(res.send.calledOnce).to.be.true;
            expect(res.send.firstCall.args[0]).to.equal("Error");
            expect(isLoggedInStub.calledOnce).to.be.true;
        });

        it("should send Hello if Logged In using Mocks", function () {
            let user = {
                isLoggedIn: function () { }
            }

            const isLoggedInStub = sinon.stub(user, "isLoggedIn").returns(true);

            let req = {
                user: user
            };
            let res = {
                send: function () { }
            };

            const mock = sinon.mock(res);
            mock.expects("send").once().withExactArgs("Hello");

            appCtrl.getStubPage(req, res);
            expect(isLoggedInStub.calledOnce).to.be.true;

            mock.verify();
        });
    });

    describe("User", function () {
        describe("addUser", function () {
            it("should add an user", function () {
                sinon.spy(user, "addUser");

                user.addUser('Manish');
                expect(user.addUser.calledOnce).to.be.true;
            });
        })
    })

    describe("AsyncTests", function () {
        // this.timeout(10000);

        it("should return Hello if true is passed", function (done) {
            myAsyncFunction(true, function (data) {
                expect(data).to.equal("Hello");
                done();
            });
        });

        it("should return Hi if false is passed", function (done) {
            myAsyncFunction(false, function (data) {
                expect(data).to.equal("Hi");
                done();
            });
        });

        it("should return Hello if true is passed using Promise", function () {
            return expect(myPromisseFunction(true)).to.eventually.equal("Hello");
        });

        it("should return Hi if false is passed using Promise", function () {
            return expect(myPromisseFunction(false)).to.eventually.equal("Hi");
        });
    })
});

function myAsyncFunction(boolValue, cb) {
    setTimeout(function () {
        console.log("Call Completed -" + boolValue);
        cb(boolValue ? "Hello" : "Hi");
    }, 1000);
}

function myPromisseFunction(boolValue) {
    return new Promise(function (resolve) {
        setTimeout(function () {
            console.log("Call Completed -" + boolValue);
            resolve(boolValue ? "Hello" : "Hi");
        }, 1000);
    });
}

const user = {
    addUser: (name) => {
        this.name = name;
    }
}