// const assert = require("assert");

// describe('first test', function () {
//     it('checks equality 1', function () {
//         assert.equal(2 + 2, 4);
//     });

//     it('checks equality 2', function () {
//         // assert.equal(2 + 2, 5);
//     });
// });

// --------------------------------------- Different Ways
// var assert = require('chai').assert;
// var expect = require('chai').expect;
// var should = require('chai').should();

// var numbers = [1, 2, 3, 4, 5];

// describe('chat assertion styles', function () {
//     it('assert style check', function () {
//         assert.isArray(numbers, 'is array of numbers');
//         assert.include(numbers, 2, 'array contains 2');
//         assert.lengthOf(numbers, 5, 'array contains 5 numbers');
//     });

//     it('expect style check', function () {
//         expect(numbers).to.be.an('array').that.includes(2);
//         expect(numbers).to.have.lengthOf(5);
//     });

//     it('should() style check', function () {
//         numbers.should.be.an('array').that.includes(2);
//         numbers.should.have.lengthOf(5);
//     });
// });

// ----------------------------------------------
// var expect = require('chai').expect;

// describe('first test', function () {
//     it('checks equality 1', function () {
//         expect(2 + 2).to.be.equal(4);
//     });
// });