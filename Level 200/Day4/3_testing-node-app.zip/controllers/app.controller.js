module.exports = {
    getIndexPage: (req, res) => {
        return res.send("Hello");
    },

    getStubPage: (req, res) => {
        if (req.user.isLoggedIn()) {
            return res.send("Hello");
        }

        return res.send("Error");
    }
}