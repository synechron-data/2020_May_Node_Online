const AWS = require('aws-sdk');
AWS.config.update({ region: 'ap-south-1' });

var createTopic = new AWS.SNS({ apiVersion: '2020-06-20' }).createTopic({ Name: "MY_TOPIC" }).promise();

createTopic.then((data) => {
    console.log("Topic ARN is " + data.TopicArn);
}).catch((err) => {
    console.log(err);
});