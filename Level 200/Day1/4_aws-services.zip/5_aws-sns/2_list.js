const AWS = require('aws-sdk');
AWS.config.update({ region: 'ap-south-1' });

var topicLists = new AWS.SNS({ apiVersion: '2020-06-20' }).listTopics({}).promise();

topicLists.then((data) => {
    console.log(data.Topics);
}).catch((err) => {
    console.log(err);
});