const AWS = require('aws-sdk');
AWS.config.update({ region: 'ap-south-1' });
const kms = new AWS.KMS();

const KeyId = '3e15e1cf-5e9d-4478-80d1-a4db8954ca41';
const Plaintext = 'The data to encrypt';

const params = {
    KeyId: KeyId,
    Plaintext: Plaintext
};

kms.encrypt(params, (err, data) => {
    if (err)
        console.log(err);
    else {
        console.log(data.CiphertextBlob);

        const params = {
            CiphertextBlob: data.CiphertextBlob
        }

        kms.decrypt(params, (err, data) => {
            if (err)
                console.log(err);
            else {
                console.log(data.Plaintext);
                console.log(data.Plaintext.toString('utf-8'));
            }
        })
    }
});