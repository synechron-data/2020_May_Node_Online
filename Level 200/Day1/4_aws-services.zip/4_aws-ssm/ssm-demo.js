const AWS = require('aws-sdk');
AWS.config.update({ region: 'ap-south-1' });
const ssm = new AWS.SSM();

const saveSecret = (username, password) => {
    const secretName = `/${username}/passwordString`;
    console.log(`Saving secret to ${secretName}`);

    const config = {
        Name: secretName,
        Value: password,
        Type: 'SecureString',
        Overwrite: true
    };

    ssm.putParameter(config, (err, data) => {
        if (err)
            console.log(err);
    });
}

const getSecret = async (secretName) => {
    console.log(`Getting secret to ${secretName}`);

    const params = {
        Name: secretName,
        // WithDecryption: false
        WithDecryption: true
    };

    const result = await ssm.getParameter(params).promise();
    return result.Parameter.Value;
}

// saveSecret("manish", "manish@1234");
getSecret('/manish/passwordString').then((password) => {
    console.log(password);
});