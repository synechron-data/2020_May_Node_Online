const AWS = require('aws-sdk');
AWS.config.update({ region: 'ap-south-1' });

const sqs = new AWS.SQS({ apiVersion: '2020-06-20' });

var params = {
    QueueName: 'MY-QUEUE',
    Attributes: {
        'DelaySeconds': '60',
        'MessageRetentionPeriod': '86400'
    }
};

sqs.createQueue(params, function (err, data) {
    if (err) {
        console.log("Error", err);
    } else {
        console.log("Success", data.QueueUrl);
    }
});