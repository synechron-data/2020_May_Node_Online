const AWS = require('aws-sdk');
AWS.config.update({ region: 'ap-south-1' });

const sqs = new AWS.SQS({ apiVersion: '2020-06-20' });

var params = {
    QueueName: 'MY-QUEUE'
};

sqs.getQueueUrl(params, function (err, data) {
    if (err) {
        console.log("Error", err);
    } else {
        let params = {
            QueueUrl: data.QueueUrl
        };

        sqs.deleteQueue(params, function (err, data) {
            if (err) {
                console.log("Error", err);
            } else {
                console.log("Success", data);
            }
        })
    }
});