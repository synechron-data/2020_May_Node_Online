const AWS = require('aws-sdk');
AWS.config.update({ region: 'ap-south-1' });

const s3 = new AWS.S3({ apiVersion: '2020-06-20' });

var bParams = {
    Bucket: 'manishvbn-test-node'
}

s3.deleteBucket(bParams, function (err, data) {
    if (err) {
        console.log("Error", err);
    } else {
        console.log("Success", data);
    }
});