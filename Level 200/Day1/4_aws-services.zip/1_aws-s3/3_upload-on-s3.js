const AWS = require('aws-sdk');
AWS.config.update({ region: 'ap-south-1' });

const s3 = new AWS.S3({ apiVersion: '2020-06-20' });

var uploadParams = {
    Bucket: 'manishvbn-test-node',
    Key: '',
    Body: ''
}

var file = "./my-file.txt";

var fs = require('fs');

var fileStream = fs.createReadStream(file);

fileStream.on('error', function (err) {
    console.log("File error: ", err);
});

uploadParams.Body = fileStream;
var path = require('path');
uploadParams.Key = path.basename(file);

s3.upload(uploadParams, function (err, data) {
    if (err) {
        console.log("Error", err);
    } else {
        console.log("Upload Success", data.Location);
    }
});