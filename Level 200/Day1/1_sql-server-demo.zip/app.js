const sql = require('mssql');

const config = {
    user: 'sa',
    password: 'sa',
    server: 'localhost\\SQLEXPRESS',
    database: 'Northwind'
};

sql.connect(config).then(pool => {
    // console.log("Connected....");

    return pool.request()
        .input('input_parameter', sql.NChar, 'ALFKI')
        .query('select * from Customers where CustomerID = @input_parameter')
    
    // return pool.request()
    //     .query('select * from Customers')
}).then(result => {
    console.log(result.recordset);
}).catch(err => {
    console.log(err);
});