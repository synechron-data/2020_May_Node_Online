class User {
    constructor(uname, email) {
        this.username = uname;
        this.email = email
    }
}

module.exports = User;