// var fs = require('fs');

// var user = {
//     username: 'Manish',
//     password: 'Sharma',
//     city: 'Pune',
//     group: 'Admin'
// };

// var data = JSON.stringify(user);

// fs.writeFile('./config.json', data, function (err) {
//     if (err) {
//         console.log("There has been an error while saving your configuration data.");
//         console.log(err.message);
//         return;
//     }
//     console.log("Configuration save successfully.");
// });

// ---------------------------------------- Read File
// var data = fs.readFileSync('./config.json');
// var myObj;
// try {
//     myObj = JSON.parse(data);
//     console.log(myObj);
// } catch (err) {
//     console.log("There has been an error parsing your JSON.");
//     console.log(err);
// }

// --------------------------------------- nConf
// var nconf = require('nconf');

// nconf.argv();

// // Read the configuration settings from JSON file 
// nconf.file({
//     file: nconf.get('config-file-path') || './config.json',
//     // Setting the separator as dot for nested objects
//     logicalSeperator: '.'
// });
// console.log(nconf.get('username'));

// ------------------------------------------ Hierarchy
var nconf = require('nconf');

// nconf.overrides({
//     "httpPort": "5000"
// });

nconf.argv();           // Command Line

nconf.env();            // Env Variable

nconf.file({            // From File
    file: nconf.get('config-file-path') || './config.json',
    logicalSeperator: '.'
});

nconf.defaults({        // Default
    "httpPort": "3000"
});


console.log("Port Number: ", nconf.get('httpPort'));