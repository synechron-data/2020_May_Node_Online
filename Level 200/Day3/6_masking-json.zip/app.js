// var inputData = { "name": "Manish", "accountNumber": "3044444444", "city": "Pune" };

// var outData = JSON.stringify(inputData, maskFn);

// function maskFn(key, value) {
//     var maskedValue = value;
//     if (key == "accountNumber") {
//         if (value && value.length > 5) {
//             maskedValue = "*" + maskedValue.substring(value.length - 4, value.length);
//         } else {
//             maskedValue = "****";
//         }
//     }
//     return maskedValue;
// }

// console.log(outData);

// ------------------------------------------------------------- Using mask-json
const maskJSON = require('mask-json')(['accountNumber']);

var inputData = { "name": "Manish", "accountNumber": "3044444444", "city": "Pune" };

var outData = maskJSON(inputData);

console.log(outData);

console.log(JSON.stringify(outData));