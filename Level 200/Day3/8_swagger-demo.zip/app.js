const express = require('express');
const router = express.Router();
const bodyParser = require('body-parser');
const swaggerUi = require('swagger-ui-express');
const swaggerDocument = require('./swagger.json');

const mongoose = require('mongoose');
const Schema = mongoose.Schema;

mongoose.set('useUnifiedTopology', true);
mongoose.connect('mongodb://localhost:27017/swagger-demo', {
    useCreateIndex: true,
    useNewUrlParser: true
});

var UserSchema = new Schema({
    firstName: { type: String },
    lastName: { type: String },
    email: { type: String }
});

mongoose.model('User', UserSchema);
var User = require('mongoose').model('User');


var app = express();

//rest API requirements
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

var createUser = function (req, res, next) {
    var user = new User(req.body);

    user.save(function (err) {
        if (err) {
            next(err);
        } else {
            res.json(user);
        }
    });
};

var updateUser = function (req, res, next) {
    User.findByIdAndUpdate(req.body._id, req.body, { new: true }, function (err, user) {
        if (err) {
            next(err);
        } else {
            res.json(user);
        }
    });
};

var deleteUser = function (req, res, next) {
    req.user.remove(function (err) {
        if (err) {
            next(err);
        } else {
            res.json(req.user);
        }
    });
};

var getAllUsers = function (req, res, next) {
    User.find(function (err, users) {
        if (err) {
            next(err);
        } else {
            res.json(users);
        }
    });
};

var getOneUser = function (req, res) {
    res.json(req.user);
};

var getByIdUser = function (req, res, next, id) {
    User.findOne({ _id: id }, function (err, user) {
        if (err) {
            next(err);
        } else {
            req.user = user;
            next();
        }
    });
};

router.route('/users').post(createUser).get(getAllUsers);
router.route('/users/:userId').get(getOneUser).put(updateUser).delete(deleteUser);

router.param('userId', getByIdUser);

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
app.use('/api/v1', router);

app.listen(3000);
module.exports = app;