// const jose = require('jose');
// console.log(jose);

// Json Web Signature - JWS
// Json Web Encryption - JWE
// Json Web Key - JWK
// Json Web Token - JWT
// Json Web Algorithms - JWA

const { JWK: { None, generateSync }, JWT } = require('jose');
const key = generateSync('RSA');

// console.log(key);

const signedJWT = JWT.sign({user: 'Manish'}, key);
console.log(signedJWT);

console.log(JWT.verify(signedJWT, key));