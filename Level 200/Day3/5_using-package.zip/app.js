const rs = require('@technizer-india/replacespaces');
console.log(rs("Hello How are You"));