const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'technizerindia@gmail.com',
        pass: 'Tech#1234'
    }
});

// const mailOptions = {
//     from: 'technizerindia@gmail.com',
//     to: 'manishvbn@gmail.com',
//     subject: 'Sending Email from Node JS Application',
//     text: 'Hello from Node JS App'
// };

// const mailOptions = {
//     from: 'technizerindia@gmail.com',
//     to: 'manishvbn@gmail.com',
//     subject: 'Sending Email from Node JS Application',
//     html: '<h1>Hello From Node</h1><p>Hello from Node JS App</p>'
// };

const mailOptions = {
    from: 'technizerindia@gmail.com',
    to: 'manishvbn@gmail.com',
    subject: 'Sending Email from Node JS Application',
    html: '<h1>Hello With Attachment</h1><p>Hello from Node JS App</p>',
    attachments: [
        {
            filename: 'notes.txt',
            content: 'Important Notes',
            contentType: 'text/plain'
        }
    ]
};

transporter.sendMail(mailOptions, function (err, info) {
    if (err) {
        console.log(err);
    } else {
        console.log("Email Sent: " + info.response);
    }
});