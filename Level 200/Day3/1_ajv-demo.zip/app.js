const Ajv = require('ajv');
const ajv = new Ajv({ allErrors: true });

const schema = {
    type: "object",
    additionalProperties: true,
    required: ["id", "firstname", "lastname", "pin"],
    properties: {
        // id: {
        //     "type": ["string", "number"],
        //     "pattern": "^[1-9][0-9]*$",
        //     "minimum": 1
        // },
        id: {
            "anyOf": [
                { "type": "string", "pattern": "^[1-9][0-9]*$" },
                { "type": "number", "minimum": 1 }
            ]
        },
        firstname: { "type": "string" },
        lastname: { "type": "string" },
        city: { "type": "string" },
        pin:
        {
            "type": "string",
            "pattern": "^[0-9]+$"
        },
        technologies: {
            "type": "array",
            "items": [
                { "type": "string" },
                { "type": "string" }
            ],
            // additionalItems: true,
            // additionalItems: false,
            additionalItems: { "type": "string" },
        }
    }
};

const validate = ajv.compile(schema);
// console.log(validate.toString());

const obj = {
    id: "1",
    firstname: "Manish",
    lastname: "Sharma",
    city: "Pune",
    pin: "411021",
    technologies: [".Net", "JS", "Java"]
};

const isValid = validate(obj);
console.log(isValid);

if (!isValid) {
    console.log(validate.errors);
}